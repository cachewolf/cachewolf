package ewe.io;
import ewe.util.*;

//##################################################################
public class StreamCorruptedException extends ObjectStreamException{
//##################################################################

public StreamCorruptedException() {super();}
public StreamCorruptedException(String message) {super(message);}

//##################################################################
}
//##################################################################

