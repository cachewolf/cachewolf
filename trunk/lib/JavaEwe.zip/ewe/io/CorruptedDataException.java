package ewe.io;

//##################################################################
public class CorruptedDataException extends IOException{
//##################################################################

public CorruptedDataException() {super();}
public CorruptedDataException(String message) {super(message);}
//===================================================================
public CorruptedDataException(Throwable cause) {super(cause);}
//===================================================================
public CorruptedDataException(String message,Throwable cause) {super(message,cause);}
//===================================================================

//##################################################################
}
//##################################################################

