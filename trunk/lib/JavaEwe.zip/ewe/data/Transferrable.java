package ewe.data;

//##################################################################
public interface Transferrable{
//##################################################################

public boolean getSetTransferData(Object transferObject,ewe.reflect.Wrapper wrapper,boolean isGet);

//##################################################################
}
//##################################################################

