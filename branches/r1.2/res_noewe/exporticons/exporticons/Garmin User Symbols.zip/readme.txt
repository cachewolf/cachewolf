English version below.

Verwendung von benutzerdefinierten Icons in Garmin GPS Ger�ten
==============================================================

1. Die Icons in diesem Archiv in Dein Garmin GPS laden. Eine detaillierte Anleitung dazu findest Du
   unter http://www.geoclub.de/ftopic10413.html
   
2. Kopiere die Datei "garminmap.xml" in das CW-Programmverzeichnis und passe sie nach Deinen Bed�rftnissen an.
    Diese Datei definiert wie die verschiedenen Cachetypen auf die benutzerdefinierten Icons abgebildet
	werden ("Custom 0" bis "Custom 23").

Die Cacheinformationen werden �ber "Anwendung"->"Export"->"zu Garmin" in das GPS exportiert. Die Datei 
"temp.loc" im Programmverzeichnis enth�lt die Liste der exportierten Caches. Durch Auslesen dieser Datei kannst
Du �berpr�fen ob die �bersetzung der Icons richtig durchgef�hrt wurde.



garminmap.xml
=============

Die Datei garminmap.xml legt fest wie die Caches auf die max. 24 benutzerdefinierten Icons abgebildet werden. Die
Nummern der internen Cachetypen findest Du weiter unten. 

WICHTIG: Die Reihenfolge der Eintr�ge in der Datei ist relevant: Der erste Eintrag, der auf den abzubildenden Cache zutrifft wird verwendet!


Fuer jedes Icon muss der folgende Eintrag angegeben werden:
-----------------------------------------------------------
     name        ...  Der Name des Icons
					
Mindestens eines dieser Attribute muss angegeben werden:
--------------------------------------------------------
Wenn mehr als ein Attribut angegeben wird, muss der Cache alle Bedingungen erfuellen um mit dem Icon dargestellt zu werden.
     type        ...   Der Typ des Caches (siehe weiter unten)
     found       ...   Der interne "gefunden" Schalter (nicht zu verwechseln mit dem "status" Feld!)
     size        ...   Die Cachegroesse in einem Buchstaben (M, S, R, L, V, N    for   Micro, Small, Regular, Large, Very Large, Not chosen)
     terrain     ...   Terrain
     difficulty  ...   Difficulty
     status      ...   Cache status (Siehe Detailpanel)
	 
Beispiel 1: Tradi-Micros mit der Schwierigkeit mindestens 4 bekommen das Icon "Custom 0" , alle anderen Tradi-Mikros das Icon "Custom 1" und
           alle anderen Tradis das Icon "Custom 2". (Beachtet die Reihenfolge der Eintraege!) 
	  
     Das Beispiel zeigt auch wie man Bereiche von Schwierigkeiten definiert (Gleiche Methode fuer Terrain Bereiche)

<icon name="Custom 0" type="2" size="M" difficulty="5" />
<icon name="Custom 0" type="2" size="M" difficulty="4.5" />
<icon name="Custom 0" type="2" size="M" difficulty="4" />
<icon name="Custom 1" type="2" size="M" />
<icon name="Custom 2" type="2" />


Beispiel 2: Alle "gefundenen" (Caches mit gesetztem internem "gefunden" Merker) als "Custom 3" darstellen
<icon name="Custom 3" type="2" found="1" />

Beispiel 3: Alle 5/5 Caches auf "Custom 4" abbilden, egal welcher Typ. 
           ACHTUNG: Wenn Du das mit Beispiel 1 kombinieren willst, muss es VOR Beispiel 1 in der garminmap.xml Datei eingefuegt werden.
<icon name="Custom 4" difficulty="5" terrain="5" />

Beispiel: Alle Nachtcaches als "Custom 5" darstellen. (Annahme: Du hast im "status" Feld den Text "Nacht" eingetragen)
<icon name="Custom 5" status="Nacht" />

HINWEIS: Der Vergleich mit dem "status" Feld prueft ob der Status mit dem gegebenen Text beginnt, d.h. auch "Nachtcache" wuerde in diesem Fall
         das Icon "Custom 5" bekommen.



===============
ENGLISH VERSION
===============




Using user defined icons with Garmin GPS 
========================================

1. Download the icons in this archive to your Garmin GPS using the xImage utility supplied by Garmin
	See: http://www.geoclub.de/ftopic10413.html (German).
	
2. Put the "garminmap.xml" file into your CW program directory.
    This file defines how the various cachetypes are mapped onto the user icons.
	
The caches can be exported via "Application"->"Export"->"to Garmin". Check the file "temp.loc" in your program directory for the correct mapping.



garminmap.xml
=============

The garminmap.xml file defines how the internal cachetypes are mapped onto the user defined icons. The internal 
cachetypes are defined in file "CacheType.java" and start with ("CW_...").

IMPORTANT NOTE: The sequence of mappings is important! The first mapping that matches is applied


For each icon the following attributes MUST be specified:
---------------------------------------------------------
     name        ...  The name of the icon
					
At least one of these attributes must be specified:
---------------------------------------------------
If more than one attribute is specified, the cache needs to match all of them to be mapped to the icon
     type        ...   The type of the cache (see below)
     found       ...   To give a different icon to found caches of a certain type
     size        ...   Single letter cachesize (M, S, R, L, V, N    for   Micro, Small, Regular, Large, Very Large, Not chosen)
     terrain     ...   Terrain
     difficulty  ...   Difficulty
     status      ...   Cache status 
	 
Example 1: This example maps Tradi-Micros of difficulty>=4 to icon "Custom 0" , all other Tradi-Micros to icon "Custom 1" and
           all other tradis to "Custom 2". 
	  
     This example also shows how to specify a range of difficulties by including multiple lines (same method can be used for terrain ranges)

<icon name="Custom 0" type="2" size="M" difficulty="5" />
<icon name="Custom 0" type="2" size="M" difficulty="4.5" />
<icon name="Custom 0" type="2" size="M" difficulty="4" />
<icon name="Custom 1" type="2" size="M" />
<icon name="Custom 2" type="2" />


Example 2: Map all "founds" (caches with internal "found" flag set to true) to "Custom 3"
<icon name="Custom 3" type="2" found="1" />

Example 3: Map all 5/5 caches to "Custom 4" irrespective of type. 
           Note: If you want to combine this with example 1, it must be inserted BEFORE example 1 in the garminmap.xml file
<icon name="Custom 4" difficulty="5" terrain="5" />

Example 4: Map all night caches to "Custom 5". (Assuming that you used the "status" field to enter "Night" to distinguish night caches)
<icon name="Custom 5" status="Night" />

NOTE: The status field matches the given text (in this example "Night") if it starts with "Night". I.e. In this example a status field of
"Night cache" would result in a match.

Internal cache types:
---------------------
CW_TYPE_CUSTOM = 0
CW_TYPE_TRADITIONAL = 2
CW_TYPE_MULTI = 3
CW_TYPE_VIRTUAL = 4
CW_TYPE_LETTERBOX = 5
CW_TYPE_EVENT = 6
CW_TYPE_QUIZ = 7
CW_TYPE_UNKNOWN = 8
CW_TYPE_MATH = 108
CW_TYPE_MOVING = 9
CW_TYPE_DRIVE_IN = 10
CW_TYPE_WEBCAM = 11
CW_TYPE_LOCATIONLESS = 12
CW_TYPE_CITO = 13
CW_TYPE_PARKING = 50
CW_TYPE_STAGE = 51
CW_TYPE_QUESTION = 52
CW_TYPE_FINAL = 53
CW_TYPE_TRAILHEAD = 54
CW_TYPE_REFERENCE = 55
CW_TYPE_MEGA_EVENT = 100
CW_TYPE_WHEREIGO = 101
CW_TYPE_APE = 102
CW_TYPE_MAZE = 103
CW_TYPE_EARTH = 104
