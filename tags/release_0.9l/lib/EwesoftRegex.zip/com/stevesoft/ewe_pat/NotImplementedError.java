package//
// This software is now distributed according to
// the Lesser Gnu Public License.  Please see
// http://www.gnu.org/copyleft/lesser.txt for
// the details.
//    -- Happy Computing!
//
com.stevesoft.ewe_pat;

public class NotImplementedError extends Error {
  public NotImplementedError(String s) {
    super(s);
  }
}
