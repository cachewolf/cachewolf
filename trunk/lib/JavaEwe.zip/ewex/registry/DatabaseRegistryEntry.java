package ewex.registry;
import ewe.io.*;
import ewe.util.*;

//##################################################################
class DatabaseRegistryEntry{
//##################################################################

public String name = "";
public String savedData = "";
public int type = 0;

public static final int TYPE_STRING = 0;
public static final int TYPE_INTEGER = 1;
public static final int TYPE_BYTE_ARRAY = 2;


//##################################################################
}
//##################################################################

