package ewe.sys;

//##################################################################
public class TimedOutException extends Exception{
//##################################################################
public TimedOutException() {}
public TimedOutException(String msg) {super(msg);}
//===================================================================
public TimedOutException(Throwable cause) {super(cause);}
//===================================================================
public TimedOutException(String message,Throwable cause) {super(message,cause);}
//===================================================================
//##################################################################
}
//##################################################################

