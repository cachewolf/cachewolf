Verwendung von benutzerdefinierten Icons in Garmin GPS Ger�ten
========================================

1. Die Icons in diesem Archiv in Dein Garmin GPS laden. Eine detaillierte Anleitung dazu findest Du
   unter http://www.geoclub.de/ftopic10413.html
   
2. Kopiere die Datei "garminmap.xml" in das CW-Programmverzeichnis.
    Diese Datei definiert wie die verschiedenen Cachetypen auf die benutzerdefinierten Icons abgebildet
	werden ("Custom 0" bis "Custom 23").

Die Cacheinformationen werden �ber "Anwendung"->"Export"->"zu Garmin" in das GPS exportiert. Die Datei 
"temp.loc" im Programmverzeichnis enth�lt die Liste der exportierten Caches. Durch Auslesen dieser Datei kannst
Du �berpr�fen ob die �bersetzung der Icons richtig durchgef�hrt wurde.


Using user defined icons with Garmin GPS 
=========================

1. Download the icons in this archive to your Garmin GPS using the xImage utility supplied by Garmin
	See: http://www.geoclub.de/ftopic10413.html (German).
	
2. Put the "garminmap.xml" file into your CW program directory.
    This file defines how the various cachetypes are mapped onto the user icons.
	
The caches can be exported via "Application"->"Export"->"to Garmin".


garminmap.xml
=========

The garminmap.xml file defines how the internal cachetypes are mapped onto the user defined icons. The internal 
cachetypes are defined in file "CacheType.java" and start with ("CW_...").

Example entries:
1. Map the "traditional" cachetype (internal type=2) onto icon "Custom 0" if the cache has been found.
	<icon type="2" found="1" name="Custom 1" />

2. Map the "multi" cachetype (internal type=3) onto icon "Custom 2" (ignore the "found" status of the cache)
	<icon type="3" name="Custom 2" />

3. If two mappings exist for a given cachetype, the mapping with "found" is tried first.
	<!-- Letterbox -->
	<icon type="5" name="Custom 4" />
	<icon type="5" found="1" name="Custom 5" />
	A found "letterbox" cache is mapped onto "Custom 5". A "letterbox" which has not yet been found or been marked 
    as "not found" is mapped onto "Custom 4".


Internal cache types:
---------------------
CW_TRADITIONAL = 2;
CW_MULTI = 3;
CW_VIRTUAL = 4;
CW_LETTERBOX = 5;
CW_EVENT = 6;
CW_MYSTERY = 8;
CW_MOVING = 9;
CW_DRIVE_IN = 10;
CW_WEBCAM = 11;
CW_LOCATIONLESS = 12;
CW_CITO = 13;
CW_EARTH = 137;
CW_MEGA_EVENT = 453;
CW_PARKING = 50;
CW_STAGE_OF_MULTI = 51;
CW_QUESTION = 52;
CW_FINAL = 53;
CW_TRAILHEAD = 54;
CW_REFERENCE = 55;
CW_CNT_TYPES = 20;

	
	
