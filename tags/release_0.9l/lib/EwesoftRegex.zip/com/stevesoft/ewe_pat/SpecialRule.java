//
// This software is now distributed according to
// the Lesser Gnu Public License.  Please see
// http://www.gnu.org/copyleft/lesser.txt for
// the details.
//    -- Happy Computing!
//
package com.stevesoft.ewe_pat;

public class SpecialRule extends ReplaceRule {
    public SpecialRule() {}
    public void apply(StringBufferLike sb,RegRes rr) {}
}
