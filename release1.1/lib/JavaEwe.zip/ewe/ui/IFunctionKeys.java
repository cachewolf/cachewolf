package ewe.ui;

//##################################################################
public interface IFunctionKeys{
//##################################################################

public static final int APP0 = 75192;
public static final int APP1 = 75193;
public static final int APP2 = 75194;
public static final int APP3 = 75195;
public static final int APP4 = 75196;
public static final int APP5 = 75197;
public static final int APP6 = 75198;
public static final int APP7 = 75199;
public static final int APP8 = 75200;
public static final int APP9 = 75201;
public static final int APP10 = 75202;
public static final int APP11 = 75203;
public static final int APP12 = 75204;
public static final int APP13 = 75205;
public static final int APP14 = 75206;
public static final int APP15 = 75207;

public static final int F1 = 75192;
public static final int F2 = 75193;
public static final int F3 = 75194;
public static final int F4 = 75195;
public static final int F5 = 75196;
public static final int F6 = 75197;
public static final int F7 = 75198;
public static final int F8 = 75199;
public static final int F9 = 75200;
public static final int F10 = 75201;
public static final int F11 = 75202;
public static final int F12 = 75203;

//##################################################################
}
//##################################################################

