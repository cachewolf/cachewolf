package ewe.ui;

//##################################################################
public interface IKeypadKeys{
//##################################################################
public static final int KEYPAD_0 = 75300;
public static final int KEYPAD_1 = 75301;
public static final int KEYPAD_2 = 75302;
public static final int KEYPAD_3 = 75303;
public static final int KEYPAD_4 = 75304;
public static final int KEYPAD_5 = 75305;
public static final int KEYPAD_6 = 75306;
public static final int KEYPAD_7 = 75307;
public static final int KEYPAD_8 = 75308;
public static final int KEYPAD_9 = 75309;
public static final int KEYPAD_POINT = 75310;
public static final int KEYPAD_PLUS = 75311;
public static final int KEYPAD_MINUS = 75312;
public static final int KEYPAD_TIMES = 75313;
public static final int KEYPAD_DIVIDE = 75314;
public static final int KEYPAD_ENTER = 75315;

public static final int KEYPAD_INS = 75320;
public static final int KEYPAD_END = 75321;
public static final int KEYPAD_DOWN = 75322;
public static final int KEYPAD_PAGE_DOWN = 75323;
public static final int KEYPAD_LEFT = 75324;
//public static final int KEYPAD_ = 75325;
public static final int KEYPAD_RIGHT = 75326;
public static final int KEYPAD_HOME = 75327;
public static final int KEYPAD_UP = 75328;
public static final int KEYPAD_PAGE_UP = 75329;
public static final int KEYPAD_DEL = 75330;
//##################################################################
}
//##################################################################

